package br.edu.estudos.model;

import java.util.ArrayList;

public class Usuario {

	private Integer Codigo;
	private String nome;
	private String tipo;
	private String email;
	private String telefone;
	private String login;
	private String senha;
	private ArrayList<Curso> listaCursos = new ArrayList<Curso>();
	
	public Usuario() {
		this.Codigo = 0;
		this.nome = "";
		this.tipo = "";
		this.email = "";
		this.telefone = "";
		this.login = "";
		this.senha = "";
		this.listaCursos = new ArrayList<Curso>();
	}
	
	public Usuario(Integer codigo, String nome, String tipo, String email, String telefone, String login, String senha,	ArrayList<Curso> listaCursos) {
		this.Codigo = codigo;
		this.nome = nome;
		this.tipo = tipo;
		this.email = email;
		this.telefone = telefone;
		this.login = login;
		this.senha = senha;
		this.listaCursos = listaCursos;
	}

	public Integer getCodigo() {
		return Codigo;
	}
	public void setCodigo(Integer codigo) {
		this.Codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public ArrayList<Curso> getListaCursos() {
		return listaCursos;
	}

	public void setListaCursos(Curso listaCursos) {
		this.listaCursos.add(listaCursos);
	}
	public void setListaCursos(ArrayList<Curso> listaCursos) {
		this.listaCursos.addAll(listaCursos);
	}
	
	
	public String identificar() {
		
		return "";
	}
	
}
