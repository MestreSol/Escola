package br.edu.estudos.model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Disciplina {

	private String descricao;
	private Professor docente;
	private String modalidade;
	private Double cargaHoraria;
	private LocalDate inicio;
	private LocalDate termino;
	private Historico historico;
	
	public Disciplina() {
		this.descricao = "";
		this.docente = new Professor();
		this.modalidade = "";
		this.cargaHoraria = 0.0;
		this.inicio = null;
		this.termino = null;
		this.historico = new Historico();
	}

	public Disciplina(String descricao, Professor docente, String modalidade, Double cargaHoraria, LocalDate inicio, LocalDate termino,
			          ArrayList<Double> listaNotas, Double frequencia ) {
		this.descricao = descricao;
		this.docente = docente;
		this.modalidade = modalidade;
		this.cargaHoraria = cargaHoraria;
		this.inicio = inicio;
		this.termino = termino;
		// Inicializa os atributos de Historico por ser uma rela��o de Composi��o
		this.historico = new Historico(listaNotas, frequencia);
	}

	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public Professor getDocente() {
		return docente;
	}
	public void setDocente(Professor docente) {
		this.docente = docente;
	}
	public String getModalidade() {
		return modalidade;
	}
	public void setModalidade(String modalidade) {
		this.modalidade = modalidade;
	}
	public double getCargaHoraria() {
		return cargaHoraria;
	}
	public void setCargaHoraria(Double cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}
	public LocalDate getInicio() {
		return inicio;
	}
	public void setInicio(LocalDate inicio) {
		this.inicio = inicio;
	}
	public LocalDate getTermino() {
		return termino;
	}
	public void setTermino(LocalDate termino) {
		this.termino = termino;
	}
	public Historico getHistorico() {
		return historico;
	}
	public void setHistorico(Historico historico) {
		this.historico = historico;
	}


	public String verificarSituacao() {
		
		String mensagem = "";
		
		if(this.getHistorico().calcularNotaFinal() >= 6.0 && (this.getHistorico().getFrequencia() / this.getCargaHoraria()) >= 0.75) {
			mensagem = "Aprovado";
		}else {
			mensagem = "Reprovado";
		}
		
		return mensagem;
	}

	
	public String emitirHistorico() {
		
		
		return "";
	}
}
