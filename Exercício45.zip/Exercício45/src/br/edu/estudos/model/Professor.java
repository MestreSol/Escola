package br.edu.estudos.model;

public class Professor {

	private String nome;
	private String area;
	private String contato;
	
	public Professor() {
		this.nome = "";
		this.area = "";
		this.contato = "";
	}
	public Professor(String nome, String area, String contato) {
		this.nome = nome;
		this.area = area;
		this.contato = contato;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getContato() {
		return contato;
	}
	public void setContato(String contato) {
		this.contato = contato;
	}
	
	// Sobrescrita do m�todo toString (que retorna originalmente a identifica��o do objeto em mem�ria) 
	// retornando uma String com o nome do professor para apresenta��o no ComboBox do formul�rio de disciplinas
	public String toString() {
		return this.nome;
	}
}
