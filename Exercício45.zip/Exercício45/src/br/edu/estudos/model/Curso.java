package br.edu.estudos.model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Curso {

	private String descricao;
	private String modalidade;
	private LocalDate inicio;
	private LocalDate termino;
	private ArrayList<Disciplina> listaDisciplinas = new ArrayList<Disciplina>();
	
	public Curso() {
		this.descricao = "";
		this.modalidade = "";
		this.inicio = null;
		this.termino = null;
		this.listaDisciplinas = new ArrayList<Disciplina>();
	}
	public Curso(String descricao, String modalidade, LocalDate inicio, LocalDate termino, ArrayList<Disciplina> listaDisciplinas) {
		this.descricao = descricao;
		this.modalidade = modalidade;
		this.inicio = inicio;
		this.termino = termino;
		this.listaDisciplinas = listaDisciplinas;
	}
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getModalidade() {
		return modalidade;
	}
	public void setModalidade(String modalidade) {
		this.modalidade = modalidade;
	}
	public LocalDate getInicio() {
		return inicio;
	}
	public void setInicio(LocalDate inicio) {
		this.inicio = inicio;
	}
	public LocalDate getTermino() {
		return termino;
	}
	public void setTermino(LocalDate termino) {
		this.termino = termino;
	}
	public ArrayList<Disciplina> getListaDisciplinas() {
		return listaDisciplinas;
	}
	
	public void setListaDisciplinas(Disciplina listaDisciplinas) {
		this.listaDisciplinas.add(listaDisciplinas);
	}
	public void setListaDisciplinas(ArrayList<Disciplina> listaDisciplinas) {
		this.listaDisciplinas.addAll(listaDisciplinas);
	}
	
	public String detalhar() {
		
		
		
		return "";
	}
	
}
