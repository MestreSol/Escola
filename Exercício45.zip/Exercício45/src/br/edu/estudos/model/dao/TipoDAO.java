package br.edu.estudos.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class TipoDAO {

	public ArrayList<String> listarTipos(){		
		
		// Declara��o de refer�ncias JDBC
		Connection con = null; 
		ResultSet rs = null;	
		Statement stmt = null;
		
		// Declara��o de vari�vel
		String sql = "";
		
		// Declara��o do ArrayList que receber� o retorno do Select
		ArrayList<String> listaTipos = new ArrayList<String>();
		
		try {
			con = GerenciadorConexoes.criarConexao();
			stmt = con.createStatement();
			// Defini��o da String SQL
			sql = "select * from estudos.tipos";
			rs = stmt.executeQuery(sql);
			// Percorre os itens do Resultset
			while(rs.next()){
				// Armazena os dados do Resultset no ArrayList
				listaTipos.add(rs.getString("tipDescricao"));
			}		
		} catch (SQLException erro) { 
			erro.printStackTrace();		
		} catch (Exception erro) { 
			erro.printStackTrace();		
		} finally{ 			
			try{
				// Finaliza o ResultSet
				if(rs != null)  rs.close();
				// Finaliza o Statement
				if(stmt != null) stmt.close();
				// Finaliza a Connection 
				if(con != null) con.close();					
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		// Retorna o ArrayList preenchido
		return listaTipos;
	}	
	
}
