package br.edu.estudos.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ModalidadeDAO {
	
	public ArrayList<String> ListarModalidades() throws SQLException{	
		ArrayList<String> ListaModalidade = new ArrayList<String>();
		try {
			
			
			Connection con = GerenciadorConexoes.criarConexao();
			Statement stmt = con.createStatement();
		
			String sql = "SELECT * FROM estudos.modalidades";
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
			
				ListaModalidade.add(rs.getString("modDescricao"));
			
			}
		}catch(Exception erro) {
			erro.printStackTrace();
		}
		return ListaModalidade;
	}
	
}
