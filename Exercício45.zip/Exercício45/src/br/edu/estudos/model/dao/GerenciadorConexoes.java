package br.edu.estudos.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GerenciadorConexoes {

	// url que identifica o banco
	private static String url = "jdbc:mysql://localhost:3306/estudos?useSSL=false&useTimezone=true&serverTimezone=UTC";
	// login de usuario no banco
	private static String usuario = "root";
	// senha do usuario no banco
	private static String senha = "";

	public static Connection criarConexao() throws SQLException {
		
		Connection conexao = null;
		// Solicita a conex�o
		conexao = DriverManager.getConnection(url, usuario, senha);		
		// Retorna o objeto de conex�o ou gera uma exce��o  
		return conexao;
	} 	
}
