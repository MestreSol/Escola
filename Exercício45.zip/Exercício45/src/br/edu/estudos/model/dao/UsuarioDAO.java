package br.edu.estudos.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import br.edu.estudos.model.Usuario;

public class UsuarioDAO {

	
	// M�todo respons�vel pela autentica��o de acesso
	public Usuario autenticar(Usuario usuario){		
		
		// Declara��o de refer�ncias JDBC
		Connection con = null;
		ResultSet rs = null;
		Statement stmt = null;
		// Declara��o de vari�vel
		String sql = "";
		
		try {
			// Faz a conex�o com o Banco
			con = GerenciadorConexoes.criarConexao();
			// Cria um objeto do tipo Statement				
			stmt = con.createStatement();
			// Define a string de SQL que deve ser executada
			sql = "select usuarios.usuNome from estudos.usuarios where usuarios.usuLogin = '" + usuario.getLogin() + "' and usuarios.usuSenha = '" + usuario.getSenha() + "'";	
			// Executa a string SQL e atribui os dados resultantes em um ResultSet
			rs = stmt.executeQuery(sql);
			
			// Tenta posicionar o ponteiro no pr�ximo registro do rs
			// Se conseguir (o select retornou um resultado) retorna true, sen�o (se o rs estiver vazio) ocorrer� uma exception
			if(rs.next()){
				// Recupera o nome do registro encontrado no banco de dados e armazena no objeto usuario
				usuario.setNome(rs.getString(1));
			}			
			
		} catch (SQLException e) {  // Captura erros referente a instru��es SQL
			e.printStackTrace();			
			
		} catch (Exception e) { // Captura erros imprevistos
			e.printStackTrace();		
			
		} finally{ // Ser� executado ocorrendo ou n�o um erro no bloco try	
			
			try{
				// Finaliza o ResultSet
				if(rs != null)  rs.close();
				// Finaliza o Statement
				if(stmt != null) stmt.close();
				// Finaliza a Connection 
				if(con != null) con.close();		
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}		
		// Retorna o objeto admProcurado
		return usuario;
	}

	
	
	public ArrayList<Usuario> listarUsuarios(){		
		
		// Declara��o de refer�ncias JDBC
		Connection con = null; 
		ResultSet rs = null;	
		Statement stmt = null;
		
		// Declara��o de vari�vel
		String sql = "";
				
		// Declara��o do ArrayList que receber� o retorno do Select
		ArrayList<Usuario> listaUsuarios = new ArrayList<Usuario>();
		
		try {
			con = GerenciadorConexoes.criarConexao();
			stmt = con.createStatement();
			// Defini��o da String SQL
			
			sql = "select usuarios.usuId, " +
				  "       tipos.tipDescricao, " +			
				  "       usuarios.usuNome, " +
				  "       usuarios.usuEmail, " +
				  "       usuarios.usuTelefone, " +				  
				  "       usuarios.usuLogin, " +
			      "       usuarios.usuSenha " +
			      "from usuarios, tipos " +
			      "where usuarios.usuId = tipos.tipId";
			
			rs = stmt.executeQuery(sql);

			while(rs.next()){
				// Objeto que receber� cada usuario encontrado (cada linha do ResultSet)
				Usuario umUsuario = new Usuario();
				// Popula o objeto com os dados do ResultSet
				umUsuario.setCodigo(rs.getInt("usuId"));
				umUsuario.setTipo(rs.getString("tipDescricao"));
				umUsuario.setNome(rs.getString("usuNome"));
				umUsuario.setEmail(rs.getString("usuEmail"));
				umUsuario.setTelefone(rs.getString("usuTelefone"));
				umUsuario.setLogin(rs.getString("usuLogin"));
				umUsuario.setSenha(rs.getString("usuSenha"));
				// Armazena o objeto no ArrayList
				listaUsuarios.add(umUsuario);
				// Elimina a refer�ncia do objeto para ser reutilizado no pr�ximo registro
				umUsuario = null;
			}
			
		} catch (SQLException erro) { // Trata possiveis erros de SQL 
			erro.printStackTrace();
		} catch (Exception erro) { 
			erro.printStackTrace();
		} finally{ 			
			try{
				// Finaliza o ResultSet
				if(rs != null)  rs.close();
				// Finaliza o Statement
				if(stmt != null) stmt.close();
				// Finaliza a Connection 
				if(con != null) con.close();					
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		// Retorna o ArrayList carregado com objetos contento os dados do ResultSet
		return listaUsuarios;
	}

	
	
}
