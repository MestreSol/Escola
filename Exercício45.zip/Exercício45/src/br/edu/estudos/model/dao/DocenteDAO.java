package br.edu.estudos.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DocenteDAO {
	public ArrayList<String> listarDocentes(){		
		
		
		Connection con = null; 
		ResultSet rs = null;	
		Statement stmt = null;
		
		
		String sql = "";
		
		
		ArrayList<String> listaDocente = new ArrayList<String>();
		
		try {
			con = GerenciadorConexoes.criarConexao();
			stmt = con.createStatement();
		
			sql = "SELECT * FROM estudos.professores";
			rs = stmt.executeQuery(sql);
		
			while(rs.next()){
		
				listaDocente.add(rs.getString("proNome")+"|"+rs.getString("proArea")+"|"+rs.getString("proContato"));
			}		
		} catch (SQLException erro) { 
			erro.printStackTrace();		
		} catch (Exception erro) { 
			erro.printStackTrace();		
		} finally{ 			
			try{
		
				if(rs != null)  rs.close();
		
				if(stmt != null) stmt.close();
		 
				if(con != null) con.close();					
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		return listaDocente;
	}	
}
