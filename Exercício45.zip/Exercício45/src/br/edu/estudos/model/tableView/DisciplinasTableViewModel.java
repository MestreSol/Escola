package br.edu.estudos.model.tableView;

import java.time.LocalDate;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;

public class DisciplinasTableViewModel {

	private final SimpleStringProperty pDescricao;
	private final SimpleDoubleProperty pCargaHoraria;
	private final SimpleStringProperty pNomeDocente;
	private final SimpleStringProperty pModalidade;
	private final SimpleObjectProperty<LocalDate> pInicio;
	private final SimpleObjectProperty<LocalDate> pTermino;
	
	public DisciplinasTableViewModel() {
		this.pDescricao = new SimpleStringProperty("");
		this.pCargaHoraria = new SimpleDoubleProperty(0);
		this.pNomeDocente = new SimpleStringProperty("");
		this.pModalidade = new SimpleStringProperty("");
		this.pInicio = new SimpleObjectProperty<LocalDate>(LocalDate.now());
		this.pTermino = new SimpleObjectProperty<LocalDate>(LocalDate.now());		
	}

	public DisciplinasTableViewModel(SimpleStringProperty pDescricao, 
			                         SimpleDoubleProperty pCargaHoraria,
			                         SimpleStringProperty pNomeDocente, 
			                         SimpleStringProperty pModalidade, 
			                         SimpleObjectProperty<LocalDate> pInicio,
			                         SimpleObjectProperty<LocalDate> pTermino) {
		this.pDescricao = pDescricao;
		this.pCargaHoraria = pCargaHoraria;
		this.pNomeDocente = pNomeDocente;
		this.pModalidade = pModalidade;
		this.pInicio = pInicio;
		this.pTermino = pTermino;
	}

	public String getpDescricao() {
		return pDescricao.get();
	}
	
	public SimpleStringProperty pDescricaoProperty() {
		return pDescricao;
	}

	public void setpDescricao(String pDescricao) {
		this.pDescricao.set(pDescricao);
	}

	
	public SimpleDoubleProperty pCargaHorariaProperty() {
		return pCargaHoraria;
	}

	public Double getpCargaHoraria() {
		return pCargaHoraria.get();
	}

	public void setpCargaHoraria(Double pCargaHoraria) {
		this.pCargaHoraria.set(pCargaHoraria);
	}

	
	public SimpleStringProperty pNomeDocenteProperty() {
		return pNomeDocente;
	}

	public String getpNomeDocente() {
		return pNomeDocente.get();
	}

	public void setpNomeDocente(String pNomeDocente) {
		this.pNomeDocente.set(pNomeDocente);
	}
	
	
	public SimpleStringProperty pModalidadeProperty() {
		return pModalidade;
	}

	public String getpModalidade() {
		return pModalidade.get();
	}

	public void setpModalidade(String pModalidade) {
		this.pModalidade.set(pModalidade);
	}
	
	
	public SimpleObjectProperty<LocalDate> pInicioProperty() {
		return pInicio;
	}

	public LocalDate getpInicio() {
		return pInicio.get();
	}

	public void setpInicio(LocalDate pInicio) {
		this.pInicio.set(pInicio);
	}

	
	public SimpleObjectProperty<LocalDate> pTerminoProperty() {
		return pTermino;
	}
	
	public LocalDate getpTermino() {
		return pTermino.get();
	}
	
	public void setpTermino(LocalDate pTermino) {
		this.pTermino.set(pTermino);
	}
	
}
