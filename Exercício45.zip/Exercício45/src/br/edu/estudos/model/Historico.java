package br.edu.estudos.model;

import java.util.ArrayList;

public class Historico {

	private ArrayList<Double> listaNotas = new ArrayList<Double>();
	private Double frequencia;
	
	public Historico() {
		this.listaNotas = new ArrayList<Double>();
		this.frequencia = 0.0;		
	}
	
	public Historico(ArrayList<Double> listaNotas, Double frequencia) {
		this.listaNotas = listaNotas;
		this.frequencia = frequencia;
	}
	
	public ArrayList<Double> getListaNotas() {
		return listaNotas;
	}
	public void setListaNotas(Double listaNotas) {
		this.listaNotas.add(listaNotas);
	}
	public void setListaNotas(ArrayList<Double> listaNotas) {
		this.listaNotas.addAll(listaNotas);
	}
	public double getFrequencia() {
		return frequencia;
	}
	public void setFrequencia(Double frequencia) {
		this.frequencia = frequencia;
	}
	
	
	public Double calcularNotaFinal() {
		
		double somatoria = 0;
		
		for(Double nota : this.getListaNotas()) {
			somatoria += nota; 
		}

		return somatoria / this.getListaNotas().size();
	}	
	
}
