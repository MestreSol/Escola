package br.edu.estudos.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import br.edu.estudos.model.Usuario;
import br.edu.estudos.model.dao.TipoDAO;
import br.edu.estudos.model.dao.UsuarioDAO;
import br.edu.estudos.model.tableView.UsuariosTableViewModel;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class JFXUsuariosControle implements Initializable{
	
	TipoDAO tipos = new TipoDAO();
	UsuarioDAO usuarioDAO = new UsuarioDAO();
	
	// Atributos
	private Stage palcoUsuarios;
	private ArrayList<UsuariosTableViewModel> listaUsuariosTvModel = new ArrayList<UsuariosTableViewModel>(); 
	private String operacao;
	
	// Componentes JavaFX
	@FXML Button bInserir;
	@FXML Button bAlterar;
	@FXML ComboBox<String> cbTipo;
	@FXML TableView<UsuariosTableViewModel> tvUsuarios;
	@FXML TableColumn<UsuariosTableViewModel, String> colCodigo;
	@FXML TableColumn<UsuariosTableViewModel, String> colNome;
	@FXML TableColumn<UsuariosTableViewModel, String> colLogin;
	@FXML TableColumn<UsuariosTableViewModel, String> colSenha;
	@FXML Button bExcluir;
	@FXML Button bConfirmar;
	@FXML Button bCancelar;
	@FXML TextField tfNome;
	@FXML Label lFechar;
	@FXML TextField tfCodigo;
	@FXML TextField tfEmail;
	@FXML TextField tfTelefone;
	@FXML TextField tfLogin;
	@FXML PasswordField pfSenha;
	
	
	// Metodos de acesso
	public Stage getPalcoUsuarios() {
		return palcoUsuarios;
	}

	public void setPalcoUsuarios(Stage palcoUsuarios) {
		this.palcoUsuarios = palcoUsuarios;
	}

	public ArrayList<UsuariosTableViewModel> getListaUsuariosTvModel() {
		return listaUsuariosTvModel;
	}

	// Sobrecarga do m�todo setListaDisciplinas
	public void setListaUsuariosTvModel(UsuariosTableViewModel usuarioTvModel) {
		this.listaUsuariosTvModel.add(usuarioTvModel);
	}
	public void setListaUsuariosTvModel(ArrayList<UsuariosTableViewModel> listaUsuariosTvModel) {
		this.listaUsuariosTvModel.addAll(listaUsuariosTvModel);
	}
	
	private String getOperacao() {
		return operacao;
	}

	private void setOperacao(String operacao) {
		this.operacao = operacao;
	}


	// Funcionalidades do formul�rio

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
				
		colCodigo.setCellValueFactory( new PropertyValueFactory<>("pCodigo"));
		colNome.setCellValueFactory(  new PropertyValueFactory<>( "pNome" ) );		
		colLogin.setCellValueFactory( new PropertyValueFactory<>("pLogin") );
		colSenha.setCellValueFactory( new PropertyValueFactory<>("pSenha"));

		bConfirmar.setVisible(false);
		bCancelar.setVisible(false);
		tfNome.requestFocus();
		
		// Preenche o ComboBox com os tipos armazenadas no banco de dados
		cbTipo.setItems(FXCollections.observableArrayList(tipos.listarTipos()));
		
		// Preenche o TableView com os Usuarios armazenados no banco de dados		
		this.atualizarTableView();
	}


	public ArrayList<UsuariosTableViewModel> carregaUsuariosTableViewModel(){
		
		this.getListaUsuariosTvModel().clear();
		
		// Percorre o ArrayList de Usuarios retornado pelo m�todo listarusuarios do objeto usuarioDAO
		// carregando um ArrayList de usuarioTableViewModel (modelo da TableView) 
		for (Usuario usuario : usuarioDAO.listarUsuarios()) {
			
			UsuariosTableViewModel umUsuarioTvModel = new UsuariosTableViewModel();
			
			umUsuarioTvModel.setpCodigo(usuario.getCodigo());
			umUsuarioTvModel.setpNome(usuario.getNome());
			umUsuarioTvModel.setpTipo(usuario.getTipo());
			umUsuarioTvModel.setpEmail(usuario.getEmail());
			umUsuarioTvModel.setpTelefone(usuario.getTelefone());
			umUsuarioTvModel.setpLogin(usuario.getLogin());
			umUsuarioTvModel.setpSenha(usuario.getSenha());
	
			this.setListaUsuariosTvModel(umUsuarioTvModel);
		}	
		return this.getListaUsuariosTvModel();	 
	}

	
	public void atualizarTableView() {
		
		// Sincroniza o modelo do tvUsuarios com o Banco de Dados
		this.carregaUsuariosTableViewModel();

		// Vincula o atributo listaUsuarios como fonte de dados para a tabela
		tvUsuarios.setItems(FXCollections.observableArrayList(this.getListaUsuariosTvModel()));
		
		// Atualiza visualiza��o dos dados 
		tvUsuarios.refresh();
	}

	
	@FXML public void inserir() {

		this.habilitarCampos();
		this.limparCampos();
		this.ajustarBotoesInserir();

		tfNome.requestFocus();

		// Identifica a opera��o e ajusta os bot�es
		this.setOperacao("inserir");
		this.ajustarBotoesInserir();			
	}


	@FXML public void alterar() {

		try {

			// Verifica se nenhum usuario foi selecionado
			if(tvUsuarios.getSelectionModel().getSelectedIndex() < 0) {
				throw new IOException();
			}

			this.habilitarCampos();
			this.ajustarBotoesAlterar();
			tfNome.requestFocus();

			// Identifica a opera��o e ajusta os bot�es		
			this.setOperacao("alterar");			

		} catch (IOException e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Ops!");
			alert.setHeaderText("Opera��o n�o pode ser realizada");
			alert.setContentText("Selecione um usuario para altera��o");
			alert.showAndWait();				
		} catch (Exception e) {
			// A exce��o ocorre quando uma exception diferente das tratadas acima � gerada.
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Opera��o n�o realizada");
			alert.setHeaderText("Ocorreu um problema no processo de entrada");
			alert.setContentText("Favor entrar em contato com os desenvolvedores!");
			alert.showAndWait();
			// Detalhes do erro imprevisto
			e.printStackTrace();
		}				
	}		
	


	@FXML public void excluir() {
	
		// Verifica se um usuario foi selecionado
		if(tvUsuarios.getSelectionModel().getSelectedIndex() >= 0) {
			
			// Identifica a opera��o e ajusta os bot�es		
			this.setOperacao("excluir");
			this.ajustarBotoesExcluir();
			
		}else {

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Alerta");
			alert.setHeaderText("Exclus�o n�o realizada");
			alert.setContentText("Selecione um usuario para exclus�o");
			alert.showAndWait();
		}		

	}

	
	@FXML public void confirmar() {

		try {

			// Verifica campos obrigat�rios
			if (cbTipo.getSelectionModel().getSelectedItem() == null ||
				tfNome.getText().isEmpty() ||
				tfLogin.getText().isEmpty() ||   
				pfSenha.getText().isEmpty()) {

				// Define a mensagem de erro
				throw new IOException("Todos os campos s�o obrigat�rios.");	
			}

			// Se a opera��o for inserir
			if(this.getOperacao().equals("inserir")) {

				// Cria um objeto Usuario para receber os dados lidos pelo formul�rio
				UsuariosTableViewModel novaUsuarioTvModel = new UsuariosTableViewModel();

				novaUsuarioTvModel.setpTipo(cbTipo.getSelectionModel().getSelectedItem().toString());
				novaUsuarioTvModel.setpNome(tfNome.getText());
				novaUsuarioTvModel.setpEmail(tfEmail.getText());
				novaUsuarioTvModel.setpTelefone(tfTelefone.getText());
				novaUsuarioTvModel.setpLogin(tfLogin.getText());
				novaUsuarioTvModel.setpSenha(pfSenha.getText().toString());

				// Insere o objeto no atributo (ArrayList) listaUsuarios
				this.setListaUsuariosTvModel(novaUsuarioTvModel);

				// Atualiza a tabela
				this.atualizarTableView();
			}


			// Se a opera��o for alterar
			if(this.getOperacao().equals("alterar")) {

				// Cria um objeto Usuario para receber os dados lidos pelo formul�rio
				UsuariosTableViewModel alteracaoUsuarioTvModel = new UsuariosTableViewModel();

				alteracaoUsuarioTvModel.setpCodigo( Integer.parseInt( tfCodigo.getText()));
				alteracaoUsuarioTvModel.setpTipo(cbTipo.getSelectionModel().getSelectedItem().toString());
				alteracaoUsuarioTvModel.setpNome(tfNome.getText());
				alteracaoUsuarioTvModel.setpEmail(tfEmail.getText());
				alteracaoUsuarioTvModel.setpTelefone(tfTelefone.getText());
				alteracaoUsuarioTvModel.setpLogin(tfLogin.getText());
				alteracaoUsuarioTvModel.setpSenha(pfSenha.getText().toString());

				// Obt�m o indice (posi��o no ArrayList) do objeto selecionado na tabela
				int indice = tvUsuarios.getSelectionModel().getSelectedIndex();

				// Insere o objeto alterado na posi��o selecionada (sobrepondo o objeto anterior)
				this.getListaUsuariosTvModel().set(indice, alteracaoUsuarioTvModel);

				// Atualiza a tabela
				this.atualizarTableView();
			}

		} catch (IOException e) {

			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Ops!");
			alert.setHeaderText("Opera��o n�o pode ser realizada");
			// Existem dois erros poss�veis que gerar�o uma IOException.
			// Ser� exibida a mensagem definida na cria��o da exception
			alert.setContentText(e.getMessage());
			alert.showAndWait();				

		} catch (Exception e) {
			// A exce��o ocorre quando uma exception diferente das tratadas acima � gerada.
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Opera��o n�o realizada");
			alert.setHeaderText("Ocorreu um problema no processo de entrada");
			alert.setContentText("Favor entrar em contato com os desenvolvedores!");
			alert.showAndWait();
			// Detalhes do erro imprevisto
			e.printStackTrace();
		}				


		if(this.getOperacao().equals("excluir")) {

			int resposta = JOptionPane.showConfirmDialog(null, "Confirma a exclus�o?", "Aten��o!", JOptionPane.YES_NO_OPTION);

			if (resposta == JOptionPane.YES_OPTION) {

				// Obt�m o indice (posi��o no ArrayList) do objeto selecionado na tabela
				int indice = tvUsuarios.getSelectionModel().getSelectedIndex();

				// Remove o objeto dessa posi��o
				this.getListaUsuariosTvModel().remove(indice);

				// Atualiza a tabela
				this.atualizarTableView();
			}
		}

		// Ajusta os campos e bot�es para a pr�xima opera��o
		this.limparCampos();
		this.ajustarBotoesInicial();
		this.desabilitarCampos();
	}


	@FXML public void cancelar() {

		// Ajusta os bot�es para a pr�xima opera��o
		this.ajustarBotoesInicial();
		this.limparCampos();
		this.desabilitarCampos();
	}


	@FXML public void fechar() {
		this.getPalcoUsuarios().close();
	}


	// M�todos internos para as funcionalidades do formul�rio

	// Carrega os dados do objeto selecionado na tabela nos campos do formul�rio
	// Este m�todo � invocado a cada clique do mouse e a cada usuario pelo teclado na tabela
	@FXML public void carregarDados() {

		if(tvUsuarios.getSelectionModel().getSelectedIndex() < 0) {

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Opera��o inv�lida");
			alert.setHeaderText("Detalhamento:");
			alert.setContentText( "N�o h� usu�rios inseridas" );
			alert.showAndWait();

		}else {

			// Obt�m o objeto selecionado na tabela
			UsuariosTableViewModel usuarioTvModelSelecionada = tvUsuarios.getSelectionModel().getSelectedItem();

			tfCodigo.setText(usuarioTvModelSelecionada.getpCodigo().toString());
			cbTipo.setValue(usuarioTvModelSelecionada.getpTipo());
			tfNome.setText(usuarioTvModelSelecionada.getpNome());
			tfEmail.setText(usuarioTvModelSelecionada.getpEmail());
			tfTelefone.setText(usuarioTvModelSelecionada.getpTelefone());
			tfLogin.setText(usuarioTvModelSelecionada.getpLogin());
			pfSenha.setText(usuarioTvModelSelecionada.getpSenha());
		}
	}




	// Ajustes de bot�es e campos

	public void ajustarBotoesInicial() {	
		bInserir.setVisible(true);
		bAlterar.setVisible(true);
		bExcluir.setVisible(true);
		bConfirmar.setVisible(false);
		bCancelar.setVisible(false);
		lFechar.setVisible(true);
		bInserir.setDisable(false);
		bAlterar.setDisable(false);
		bExcluir.setDisable(false);
	}

	public void ajustarBotoesInserir() {
		bInserir.setVisible(true);
		bInserir.setDisable(true);
		bAlterar.setVisible(false);
		bExcluir.setVisible(false);
		bConfirmar.setVisible(true);
		bCancelar.setVisible(true);
		lFechar.setVisible(false);
	}

	public void ajustarBotoesAlterar() {
		bInserir.setVisible(false);
		bAlterar.setVisible(true);
		bAlterar.setDisable(true);
		bExcluir.setVisible(false);
		bConfirmar.setVisible(true);
		bCancelar.setVisible(true);
		lFechar.setVisible(false);
	}

	public void ajustarBotoesExcluir() {
		bInserir.setVisible(false);
		bAlterar.setVisible(false);
		bExcluir.setVisible(true);
		bExcluir.setDisable(true);
		bConfirmar.setVisible(true);
		bCancelar.setVisible(true);
		lFechar.setVisible(false);
	}

	public void habilitarCampos() {
		cbTipo.setDisable(false);
		tfNome.setDisable(false);
		tfEmail.setDisable(false);			
		tfTelefone.setDisable(false);
		tfLogin.setDisable(false);
		pfSenha.setDisable(false);
		
		cbTipo.setOpacity(1);
		tfNome.setOpacity(1);
		tfEmail.setOpacity(1);			
		tfTelefone.setOpacity(1);
		tfLogin.setOpacity(1);
		pfSenha.setOpacity(1);
		
		tfNome.requestFocus();
	}
	
	public void desabilitarCampos() {
		cbTipo.setDisable(true);
		tfNome.setDisable(true);
		tfEmail.setDisable(true);			
		tfTelefone.setDisable(true);
		tfLogin.setDisable(true);
		pfSenha.setDisable(true);
		
		cbTipo.setOpacity(0.8);
		tfNome.setOpacity(0.8);
		tfEmail.setOpacity(0.8);			
		tfTelefone.setOpacity(0.8);
		tfLogin.setOpacity(0.8);
		pfSenha.setOpacity(0.8);
	}
	
	public void limparCampos() {

		cbTipo.setValue("");
		tfNome.clear();
		tfEmail.clear();
		tfTelefone.clear();
		tfLogin.clear();
		pfSenha.clear();

		tfNome.requestFocus();
	}

}
