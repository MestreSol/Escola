package br.edu.estudos.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.edu.estudos.model.Usuario;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class JFXPrincipalControle implements Initializable {

	// Atributos
	private Usuario usuarioLogado;
	private Stage palcoPrincipal;

	// M�todos de acesso aos atributos
	public Usuario getUsuarioLogado() {
		return usuarioLogado;
	}
	public void setUsuarioLogado(Usuario usuarioLogado) {
		this.usuarioLogado = usuarioLogado;
	}
	public Stage getPalcoPrincipal() {
		return palcoPrincipal;
	}
	public void setPalcoPrincipal(Stage palcoPrincipal) {
		this.palcoPrincipal = palcoPrincipal;
	}

	
	@FXML Label lFechar;
	@FXML MenuItem menuCursos;
	@FXML MenuItem menuDisciplinas;
	@FXML MenuItem menuProfessores;
	@FXML MenuItem menuUsuarios;
	@FXML Label lUsuarioLogado;
	@FXML Button bSair;

	
	// M�todos de acesso ao cont�udo armazenado no menuUsuarioLogado (somente para identifica��o do usu�rio logado)
	public String getMenuUsuarioLogado() {
		return this.lUsuarioLogado.getText();
	}
	public void setlMenuUsuarioLogado(String usuarioLogado) {
		this.lUsuarioLogado.setText(usuarioLogado);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		// Ajusta o tamanho do Label ao tamanho da tela (menos 10 pixels para melhor vizualiza��o)
		lUsuarioLogado.setPrefWidth(Screen.getPrimary().getVisualBounds().getWidth() - 10);
		// Ajusta a posi��o do bot�o ao tamanho da tela menos o tamanho do bot�o 
		// (que � 75 px + 10 px para melhor vizualiza��o)
		bSair.setLayoutX(Screen.getPrimary().getVisualBounds().getWidth() - 85);
	}

	
	@FXML public void abrirUsuarios() throws IOException {
		// Cria um novo palco
		Stage stage = new Stage();
		// Objeto FMXLLoader que carrega o arquivo fxml
		FXMLLoader loader = new FXMLLoader();
		// Carregamento o arquivo fxml
		loader.setLocation(getClass().getResource("/br/edu/estudos/view/JFXUsuariosLayout.fxml"));
		// Cria��o do Layout Pane (gerenciador de layout), que ser� o node/n�/componente raiz, e vinculo com o arquivo fxml
		Pane node =  loader.load();
		// Atribui��o do componente a cena
		Scene scene = new Scene(node);
		// Atribui��o da cena ao novo palco
		stage.setScene(scene);

		// O objeto loader possui a refer�ncia da classe JFXusuariosControle 
		JFXUsuariosControle usuariosControle = loader.getController();	
		// E acesso a seus m�todos.
		// A refer�ncia do palco criado � passada para posterior acesso (fechamento)
		usuariosControle.setPalcoUsuarios(stage);
		
		// Retira a barra superior da janela (icone, titulo, minimizar, maximizar e fechar)
		stage.initStyle(StageStyle.UNDECORATED);
		// N�o permite o redimensionamento
		stage.setResizable(false);
		// Centraliza a apresenta��o
		stage.centerOnScreen();
		// Define o comportamento Modal (bloqueia os demais formul�rios enquanto ele estiver aberto)
		stage.initModality(Modality.WINDOW_MODAL);
		// Indica que esse formul�rio (principal) ficar� bloqueado enquanto o formul�rio de nativos estiver ativo
		stage.initOwner(this.getPalcoPrincipal());
		// Apresenta o formul�rio
		stage.show();				
	}
	
	
	@FXML public void abrirDisciplinas() throws IOException {
		// Cria um novo palco
		Stage stage = new Stage();
		// Objeto FMXLLoader que carrega o arquivo fxml
		FXMLLoader loader = new FXMLLoader();
		// Carregamento o arquivo fxml
		loader.setLocation(getClass().getResource("/br/edu/estudos/view/JFXDisciplinasLayout.fxml"));
		// Cria��o do Layout Pane (gerenciador de layout), que ser� o node/n�/componente raiz, e vinculo com o arquivo fxml
		Pane node =  loader.load();
		// Atribui��o do componente a cena
		Scene scene = new Scene(node);
		// Atribui��o da cena ao novo palco
		stage.setScene(scene);

		// O objeto loader possui a refer�ncia da classe JFXDisciplinasControle 
		JFXDisciplinasControle disciplinasControle = loader.getController();	
		// E acesso a seus m�todos.
		// A refer�ncia do palco criado � passada para posterior acesso (fechamento)
		disciplinasControle.setPalcoDisciplinas(stage);
		
		// Retira a barra superior da janela (icone, titulo, minimizar, maximizar e fechar)
		stage.initStyle(StageStyle.UNDECORATED);
		// N�o permite o redimensionamento
		stage.setResizable(false);
		// Centraliza a apresenta��o
		stage.centerOnScreen();
		// Define o comportamento Modal (bloqueia os demais formul�rios enquanto ele estiver aberto)
		stage.initModality(Modality.WINDOW_MODAL);
		// Indica que esse formul�rio (principal) ficar� bloqueado enquanto o formul�rio de nativos estiver ativo
		stage.initOwner(this.getPalcoPrincipal());
		// Apresenta o formul�rio
		stage.show();		
	}
	
	
	@FXML public void abrirProfessores() {}

	@FXML public void abrirCursos() {}
	
	@FXML public void sair() {
		System.exit(0);
	}

	
	
	
}
