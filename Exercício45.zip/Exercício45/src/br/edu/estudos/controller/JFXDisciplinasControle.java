package br.edu.estudos.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import br.edu.estudos.model.Professor;
import br.edu.estudos.model.dao.GerenciadorConexoes;
import br.edu.estudos.model.tableView.DisciplinasTableViewModel;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;

public class JFXDisciplinasControle implements Initializable{

	Professor professor1 = new Professor("Bob Marley","Filosofia","Eva255@gmail.com");
	Professor professor2 = new Professor("Nikola Tesla","Fisica","NikoTeTe@gmail.com");
	Professor professor3 = new Professor("Friedrich Nietzsch","Sociologia","Nietzera@gmail.com");
	Professor professor4 = new Professor("Charles Bukowski","Portugues","Safadinho@gmail.com");
	
	
	
	private Stage palcoDisciplinas;
	private ArrayList<DisciplinasTableViewModel> listaDisciplinasTvModel = new ArrayList<DisciplinasTableViewModel>(); 
	private ArrayList<Professor> listaProfessores = new ArrayList<Professor>();
	private String operacao;

	@FXML Button bInserir;
	@FXML Button bAlterar;
	@FXML DatePicker dpInicio;
	@FXML ComboBox<Professor> cbDocente;
	@FXML ComboBox<String> cbModalidade;
	@FXML TableView<DisciplinasTableViewModel> tvDisciplinas;
	@FXML TableColumn<DisciplinasTableViewModel, String> colDescricao;
	@FXML TableColumn<DisciplinasTableViewModel, Double> colCargaHoraria;
	@FXML TableColumn<DisciplinasTableViewModel, String> colDocente;
	@FXML TableColumn<DisciplinasTableViewModel, String> colModalidade;
	@FXML TableColumn<DisciplinasTableViewModel, String> colInicio;
	@FXML TableColumn<DisciplinasTableViewModel, String> colTermino;
	@FXML Button bExcluir;
	@FXML Button bConfirmar;
	@FXML Button bCancelar;
	@FXML TextField tfDescricao;
	@FXML TextField tfCargaHoraria;
	@FXML DatePicker dpTermino;
	@FXML Label lFechar;	
	
	public Stage getPalcoDisciplinas() {
		return palcoDisciplinas;
	}

	public void setPalcoDisciplinas(Stage palcoDisciplinas) {
		this.palcoDisciplinas = palcoDisciplinas;
	}

	public ArrayList<DisciplinasTableViewModel> getListaDisciplinasTvModel() {
		return listaDisciplinasTvModel;
	}

	public void setListaDisciplinasTvModel(DisciplinasTableViewModel disciplinaTvModel) {
		this.listaDisciplinasTvModel.add(disciplinaTvModel);
	}
	public void setListaDisciplinasTvModel(ArrayList<DisciplinasTableViewModel> listaDisciplinasTvModel) {
		this.listaDisciplinasTvModel.addAll(listaDisciplinasTvModel);
	}
	
	public ArrayList<Professor> getListaProfessores() {
		return listaProfessores;
	}

	// Sobrecarga do m�todo setListaProfessores
	public void setListaProfessores(Professor professor) {
		this.listaProfessores.add(professor);
	}
	public void setListaProfessores(ArrayList<Professor> listaProfessores) {
		this.listaProfessores.addAll(listaProfessores);
	}

	private String getOperacao() {
		return operacao;
	}

	private void setOperacao(String operacao) {
		this.operacao = operacao;
	}


	// Funcionalidades do formul�rio

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		this.setListaProfessores(professor1);
		this.setListaProfessores(professor2);
		this.setListaProfessores(professor3);
		this.setListaProfessores(professor4);
		cbDocente.setItems(FXCollections.observableArrayList(this.getListaProfessores()));			
		
		cbModalidade.getItems().addAll("Presencial","Semi-Presencial","A dist�ncia");
		
		dpInicio.setValue(LocalDate.now());
		dpTermino.setValue(LocalDate.now());

		colDescricao.setCellValueFactory( new PropertyValueFactory<>("pDescricao"));
		colCargaHoraria.setCellValueFactory(  new PropertyValueFactory<>( "pCargaHoraria" ) );		
		colDocente.setCellValueFactory( new PropertyValueFactory<>("pNomeDocente") );
		colModalidade.setCellValueFactory( new PropertyValueFactory<>("pModalidade"));

		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		colInicio.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<DisciplinasTableViewModel,String>, ObservableValue<String>>() {
			
            public ObservableValue<String> call(CellDataFeatures<DisciplinasTableViewModel, String> cell) {
                final DisciplinasTableViewModel disciplinasTvModel = cell.getValue();
                final SimpleObjectProperty<String> dataInicioFormatada = new SimpleObjectProperty<String>(formatador.format(disciplinasTvModel.getpInicio()));
            return dataInicioFormatada;
            }        
        });

		colTermino.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<DisciplinasTableViewModel,String>, ObservableValue<String>>() {
			
            public ObservableValue<String> call(CellDataFeatures<DisciplinasTableViewModel, String> cell) {
                final DisciplinasTableViewModel disciplinasTvModel = cell.getValue();
                final SimpleObjectProperty<String> dataTerminoFormatada = new SimpleObjectProperty<String>(formatador.format(disciplinasTvModel.getpTermino()));
            return dataTerminoFormatada;
            }        
        });

		bConfirmar.setVisible(false);
		bCancelar.setVisible(false);
		tfDescricao.requestFocus();
	}


	@FXML public void inserir() {

		this.habilitarCampos();
		this.limparCampos();
		this.ajustarBotoesInserir();

		tfDescricao.requestFocus();

		// Identifica a opera��o e ajusta os bot�es
		this.setOperacao("inserir");
		this.ajustarBotoesInserir();		
	}


	@FXML public void alterar() {

		try {

			// Verifica se nenhuma disciplina foi selecionada
			if(tvDisciplinas.getSelectionModel().getSelectedIndex() < 0) {
				throw new IOException();
			}

			this.habilitarCampos();
			this.ajustarBotoesAlterar();
			tfDescricao.requestFocus();

			// Identifica a opera��o e ajusta os bot�es		
			this.setOperacao("alterar");			

		} catch (IOException e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Ops!");
			alert.setHeaderText("Opera��o n�o pode ser realizada");
			alert.setContentText("Selecione uma disciplina para altera��o");
			alert.showAndWait();				
		} catch (Exception e) {
			// A exce��o ocorre quando uma exception diferente das tratadas acima � gerada.
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Opera��o n�o realizada");
			alert.setHeaderText("Ocorreu um problema no processo de entrada");
			alert.setContentText("Favor entrar em contato com os desenvolvedores!");
			alert.showAndWait();
			// Detalhes do erro imprevisto
			e.printStackTrace();
		}				
	}		
	


	@FXML public void excluir() {
	
		// Verifica se uma discipl�ina foi selecionada
		if(tvDisciplinas.getSelectionModel().getSelectedIndex() >= 0) {
			
			// Identifica a opera��o e ajusta os bot�es		
			this.setOperacao("excluir");
			this.ajustarBotoesExcluir();
			
		}else {

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Alerta");
			alert.setHeaderText("Exclus�o n�o realizada");
			alert.setContentText("Selecione uma disciplina para exclus�o");
			alert.showAndWait();
		}		

	}

	
	@FXML public void confirmar() throws SQLException {

		try {

			// Verifica campos obrigat�rios
			if (tfDescricao.getText().isEmpty() ||
				tfCargaHoraria.getText().isEmpty() ||
				cbDocente.getSelectionModel().getSelectedItem() == null ||   
				cbModalidade.getSelectionModel().getSelectedItem() == null) {

				// Define a mensagem de erro
				throw new IOException("Todos os campos s�o obrigat�rios.");	
			}

			// Valida as datas informadas
			if( dpTermino.getValue().isBefore(dpInicio.getValue()) ) {

				// Define a mensagem de erro
				throw new IOException("A data de t�rmino n�o pode ser anterior a data de inicio!");	
			}


			// Se a opera��o for inserir
			if(this.getOperacao().equals("inserir")) {

				// Cria um objeto Disciplina para receber os dados lidos pelo formul�rio
				DisciplinasTableViewModel novaDisciplinaTvModel = new DisciplinasTableViewModel();

				novaDisciplinaTvModel.setpDescricao(tfDescricao.getText());
				novaDisciplinaTvModel.setpCargaHoraria(Double.parseDouble(tfCargaHoraria.getText()));
				novaDisciplinaTvModel.setpNomeDocente(cbDocente.getSelectionModel().getSelectedItem().toString());
				novaDisciplinaTvModel.setpModalidade(cbModalidade.getSelectionModel().getSelectedItem().toString());
				novaDisciplinaTvModel.setpInicio(dpInicio.getValue());
				novaDisciplinaTvModel.setpTermino(dpTermino.getValue());

				// Insere o objeto no atributo (ArrayList) listaDisciplinas
				this.setListaDisciplinasTvModel(novaDisciplinaTvModel);

				// Atualiza a tabela
				this.atualizarTableView();
				Connection con =  GerenciadorConexoes.criarConexao();
				
				Statement stmt = null;
				
				
				String sql = "";
				
				stmt = con.createStatement();
				
				sql = "INSERT INTO `estudos`.`disciplinas` ( `modId`, `proId`, `curId`, `hisId`, `disDescricao`, `disCargaHoraria`, `disInicio`, `disTermino`) VALUES ( '"+cbModalidade.getSelectionModel().getSelectedItem()+"', '"+cbDocente.getSelectionModel().getSelectedItem()+"', '1', '1', '"+tfDescricao.getText()+"', '"+Double.parseDouble(tfCargaHoraria.getText())+"', '"+dpInicio.getValue()+"', '"+dpTermino.getValue()+"')";
				stmt.executeQuery(sql);
				
			}


			// Se a opera��o for alterar
			if(this.getOperacao().equals("alterar")) {

				// Cria um objeto Disciplina para receber os dados lidos pelo formul�rio
				DisciplinasTableViewModel alteracaoDisciplinaTvModel = new DisciplinasTableViewModel();

				alteracaoDisciplinaTvModel.setpDescricao(tfDescricao.getText());
				alteracaoDisciplinaTvModel.setpCargaHoraria(Double.parseDouble(tfCargaHoraria.getText()));
				alteracaoDisciplinaTvModel.setpNomeDocente(cbDocente.getSelectionModel().getSelectedItem().toString());
				alteracaoDisciplinaTvModel.setpModalidade(cbModalidade.getSelectionModel().getSelectedItem().toString());
				alteracaoDisciplinaTvModel.setpInicio(dpInicio.getValue());
				alteracaoDisciplinaTvModel.setpTermino(dpTermino.getValue());

				// Obt�m o indice (posi��o no ArrayList) do objeto selecionado na tabela
				int indice = tvDisciplinas.getSelectionModel().getSelectedIndex();

				// Insere o objeto alterado na posi��o selecionada (sobrepondo o objeto anterior)
				this.getListaDisciplinasTvModel().set(indice, alteracaoDisciplinaTvModel);

				// Atualiza a tabela
				this.atualizarTableView();
				
							}

		} catch (IOException e) {

			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Ops!");
			alert.setHeaderText("Opera��o n�o pode ser realizada");
			// Existem dois erros poss�veis que gerar�o uma IOException.
			// Ser� exibida a mensagem definida na cria��o da exception
			alert.setContentText(e.getMessage());
			alert.showAndWait();				

		} catch (Exception e) {
			// A exce��o ocorre quando uma exception diferente das tratadas acima � gerada.
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Opera��o n�o realizada");
			alert.setHeaderText("Ocorreu um problema no processo de entrada");
			alert.setContentText("Favor entrar em contato com os desenvolvedores!");
			alert.showAndWait();
			// Detalhes do erro imprevisto
			e.printStackTrace();
		}				


		if(this.getOperacao().equals("excluir")) {

			int resposta = JOptionPane.showConfirmDialog(null, "Confirma a exclus�o?", "Aten��o!", JOptionPane.YES_NO_OPTION);

			if (resposta == JOptionPane.YES_OPTION) {

				// Obt�m o indice (posi��o no ArrayList) do objeto selecionado na tabela
				int indice = tvDisciplinas.getSelectionModel().getSelectedIndex();

				// Remove o objeto dessa posi��o
				this.getListaDisciplinasTvModel().remove(indice);

				// Atualiza a tabela
				this.atualizarTableView();
				Connection con =  GerenciadorConexoes.criarConexao();
				
				Statement stmt = null;
				
				
				String sql = null;
				
				stmt = con.createStatement();
				
				sql = "DELETE FROM disciplinas WHERE disId == '"+indice+"'";
				stmt.executeQuery(sql);

			}
		}

		// Ajusta os campos e bot�es para a pr�xima opera��o
		this.limparCampos();
		this.ajustarBotoesInicial();
		this.desabilitarCampos();
	}


	@FXML public void cancelar() {

		// Ajusta os bot�es para a pr�xima opera��o
		this.ajustarBotoesInicial();
		this.limparCampos();
		this.desabilitarCampos();
	}


	@FXML public void fechar() {
		this.getPalcoDisciplinas().close();
	}


	// M�todos internos para as funcionalidades do formul�rio

	// Carrega os dados do objeto selecionado na tabela nos campos do formul�rio
	// Este m�todo � invocado a cada clique do mouse e a cada disciplina pelo teclado na tabela
	@FXML public void carregarDados() {

		if(tvDisciplinas.getSelectionModel().getSelectedIndex() < 0) {

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Opera��o inv�lida");
			alert.setHeaderText("Detalhamento:");
			alert.setContentText( "N�o h� disciplinas inseridas" );
			alert.showAndWait();

		}else {

			// Obt�m o objeto selecionado na tabela
			DisciplinasTableViewModel disciplinaTvModelSelecionada = tvDisciplinas.getSelectionModel().getSelectedItem();

			tfDescricao.setText(disciplinaTvModelSelecionada.getpDescricao());		
			tfCargaHoraria.setText( String.valueOf( disciplinaTvModelSelecionada.getpCargaHoraria() ) );
			
			Professor docenteSelecionado = new Professor();
			for (Professor professor : this.getListaProfessores()) {
				
				if(professor.getNome().equals(disciplinaTvModelSelecionada.getpNomeDocente())) {
					docenteSelecionado = professor;
				}			
			}
			
			cbDocente.setValue(docenteSelecionado);
			cbModalidade.setValue(disciplinaTvModelSelecionada.getpModalidade());
			dpInicio.setValue(disciplinaTvModelSelecionada.getpInicio());
			dpTermino.setValue(disciplinaTvModelSelecionada.getpTermino());
		}
	}


	public void atualizarTableView() {
		// Vincula o atributo listaDisciplinas como fonte de dados para a tabela
		tvDisciplinas.setItems(FXCollections.observableArrayList(this.getListaDisciplinasTvModel()));
		tvDisciplinas.refresh();
	}


	// Ajustes de bot�es e campos

	public void ajustarBotoesInicial() {	
		bInserir.setVisible(true);
		bAlterar.setVisible(true);
		bExcluir.setVisible(true);
		bConfirmar.setVisible(false);
		bCancelar.setVisible(false);
		lFechar.setVisible(true);
		bInserir.setDisable(false);
		bAlterar.setDisable(false);
		bExcluir.setDisable(false);
	}

	public void ajustarBotoesInserir() {
		bInserir.setVisible(true);
		bInserir.setDisable(true);
		bAlterar.setVisible(false);
		bExcluir.setVisible(false);
		bConfirmar.setVisible(true);
		bCancelar.setVisible(true);
		lFechar.setVisible(false);
	}

	public void ajustarBotoesAlterar() {
		bInserir.setVisible(false);
		bAlterar.setVisible(true);
		bAlterar.setDisable(true);
		bExcluir.setVisible(false);
		bConfirmar.setVisible(true);
		bCancelar.setVisible(true);
		lFechar.setVisible(false);
	}

	public void ajustarBotoesExcluir() {
		bInserir.setVisible(false);
		bAlterar.setVisible(false);
		bExcluir.setVisible(true);
		bExcluir.setDisable(true);
		bConfirmar.setVisible(true);
		bCancelar.setVisible(true);
		lFechar.setVisible(false);
	}

	public void habilitarCampos() {
		tfDescricao.setDisable(false);
		tfCargaHoraria.setDisable(false);
		cbModalidade.setDisable(false);
		cbDocente.setDisable(false);			
		dpInicio.setDisable(false);
		dpTermino.setDisable(false);
		
		tfDescricao.setOpacity(1);
		tfCargaHoraria.setOpacity(1);
		cbModalidade.setOpacity(1);
		cbDocente.setOpacity(1);			
		dpInicio.setOpacity(1);
		dpTermino.setOpacity(1);
		
		tfDescricao.requestFocus();
	}
	
	public void desabilitarCampos() {
		tfDescricao.setDisable(true);
		tfCargaHoraria.setDisable(true);
		cbModalidade.setDisable(true);
		cbDocente.setDisable(true);			
		dpInicio.setDisable(true);
		dpTermino.setDisable(true);
		
		tfDescricao.setOpacity(0.8);
		tfCargaHoraria.setOpacity(0.8);
		cbModalidade.setOpacity(0.8);
		cbDocente.setOpacity(0.8);			
		dpInicio.setOpacity(0.8);
		dpTermino.setOpacity(0.8);
	}
	
	public void limparCampos() {

		tfDescricao.clear();
		tfCargaHoraria.clear();
		cbModalidade.setValue("");
		cbDocente.setValue(null);			
		dpInicio.setValue(LocalDate.now());
		dpTermino.setValue(LocalDate.now());

		tfDescricao.requestFocus();
	}

	@FXML public void validarNumeros() {

		// Cria��o de um objeto Pattern contendo a Express�o Regular a ser considerada
		// Nesse caso, tudo o que n�o (^) estiver entre 0 e 9
		Pattern pattern = Pattern.compile("[^0-9]");
		// Cria��o de um objeto Matcher que conter� a String que ser� analisada 
		Matcher matcher = pattern.matcher(tfCargaHoraria.getText());

		// Busca caracteres que satisfa�am a Express�o Regular informada
		if(matcher.find()) {

			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Carga hor�ria");
			alert.setHeaderText("Valor inv�lido");
			alert.setContentText( "Informe somente n�meros" );
			alert.showAndWait();

			tfCargaHoraria.clear();
		}
	}

}
