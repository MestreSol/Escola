package br.edu.estudos.controller;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.edu.estudos.model.dao.GerenciadorConexoes;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Inicial extends Application {


	@Override
	public void start(Stage primaryStage) throws Exception {

		FXMLLoader loader = new FXMLLoader();
		
		loader.setLocation(getClass().getResource("/br/edu/estudos/view/JFXLoginLayout.fxml"));
		
		Pane nodeRoot =  loader.load();
		Scene scene = new Scene(nodeRoot);
		
		primaryStage.setScene(scene);
		 
		JFXLoginControle loginControle = loader.getController();	
		
		loginControle.setPalcoLogin(primaryStage);
		
		primaryStage.initStyle(StageStyle.UNDECORATED);
		primaryStage.setResizable(false);
		primaryStage.centerOnScreen();
		primaryStage.show();
	
	}

	
	public static void main(String[] args) {

		try {
			
			GerenciadorConexoes.criarConexao();
			launch(args);
			
		} catch (SQLException e) {
			
			JOptionPane.showMessageDialog(null, "Verifique os arquivos de conex�o com o banco de dados", "SQLException", JOptionPane.ERROR_MESSAGE);			
			e.printStackTrace();
			
		} catch (Exception e) {
			
			e.printStackTrace();
		
		}		

	}

	
}
