-- Exclui o banco (se necessário)
-- drop database estudos;

-- Cria o banco (verificando se ele não existe)
create database if not exists estudos;
-- Abre/conecta ao banco
use estudos;

-- Criação das tabelas

-- Tabela tipos
create table if not exists estudos.tipos (
	tipId int auto_increment not null,
	tipDescricao varchar(40),
	primary key(tipId)
) engine=InnoDB;

-- Registros prévios de tipos
insert into estudos.tipos(tipDescricao) 
       values ('discente');

insert into estudos.tipos(tipDescricao) 
       values ('docente');


-- Tabela modalidades
create table if not exists estudos.modalidades (
	modId int auto_increment not null,
	modDescricao varchar(40),
	primary key(modId)
) engine=InnoDB;

-- Registros prévios de modalidades
insert into estudos.modalidades(modDescricao) 
       values ('presencial');

insert into estudos.modalidades(modDescricao) 
       values ('semi-presencial');

insert into estudos.modalidades(modDescricao) 
       values ('a distancia');


-- Tabela professores
create table if not exists estudos.professores (
	proId int auto_increment not null,
	proNome varchar(40),
    proArea varchar(30),
    proContato varchar(40),
	primary key(proId)
) engine=InnoDB;

-- Registros prévios de professores
insert into estudos.professores(proNome, proArea, proContato) 
       values ('Carl Sagan','Astronomia','sagan@cosmos.com');

insert into estudos.professores(proNome, proArea, proContato) 
       values ('Christopher Hitchens','Jornalismo','hitchens@seculary.com');

insert into estudos.professores(proNome, proArea, proContato) 
       values ('Daniel Dennett','Filosofia','dennett@oxford.com');

insert into estudos.professores(proNome, proArea, proContato) 
       values ('Richard Dawkins','Biologia','dawkins@oxford.edu');

insert into estudos.professores(proNome, proArea, proContato) 
       values ('Sam Harris','Neurociência','harris@stanford.com');

insert into estudos.professores(proNome, proArea, proContato) 
       values ('Stephen Hawking','Física','hawking@cambridge.com');


-- Tabela usuarios
create table if not exists estudos.usuarios (
	usuId int auto_increment not null,
    tipId int, -- chave estrangeira
	usuNome varchar(40),
    usuEmail varchar(40),
    usuTelefone varchar(20),
	usuLogin varchar(20),
	usuSenha varchar(20),
	primary key(usuId),
    constraint fk_usuarios_tipos foreign key(tipId) references estudos.tipos(tipId)
) engine=InnoDB;


-- Registros prévios de usuarios
insert into estudos.usuarios(tipId, usuNome, usuEmail, usuTelefone, usuLogin, usuSenha) 
       values (1,'Luciraldo Estrela da Manhã','luci@morningstar.com','(19) 9876-5432', 'luci', '123');


-- Tabela cursos
create table if not exists estudos.cursos (
	curId int auto_increment not null,
    modId int, -- chave estrangeira
    usuId int, -- chave estrangeira
	curDescricao varchar(40),
	curInicio datetime,
    curTermino datetime,
	primary key(curId),
	constraint fk_cursos_modalidades foreign key(modId) references estudos.modalidades(modId),
    constraint fk_cursos_usuarios foreign key(usuId) references estudos.usuarios(usuId)
) engine=InnoDB;


-- Tabela historicos
create table if not exists estudos.historicos (
	hisId int auto_increment not null,
	hisFrequencia float,
	primary key (hisId)
) engine=InnoDB;


-- Tabela notas
create table if not exists estudos.notas (
	notId int auto_increment not null,
	hisId int,  -- chave estrangeira
	notNota float,
	primary key (notId),
	constraint fk_notas_historicos foreign key(hisId) references estudos.historicos(hisId)
) engine=InnoDB;


-- Tabela disciplinas
create table if not exists estudos.disciplinas (
	disId int auto_increment not null,
    modId int, -- chave estrangeira
    proId int, -- chave estrangeira
    curId int, -- chave estrangeira    
    hisId int, -- chave estrangeira única (não permite registros repetidos em nenhuma das duas tabelas). Garante o relacionamento 1:1 para constraint fk_disciplinas_historicos
	disDescricao varchar(40),
    disCargaHoraria int,
	disInicio datetime,
    disTermino datetime,
	primary key(disId),
    constraint fk_disciplinas_modalidades foreign key(modId) references estudos.modalidades(modId),
    constraint fk_disciplinas_professores foreign key(proId) references estudos.professores(proId),
    constraint fk_disciplinas_cursos foreign key(curId) references estudos.cursos(curId),
    constraint fk_disciplinas_historico foreign key(hisId) references estudos.historicos(hisId)
) engine=InnoDB;



-- Consultas

-- Consultas gerais
select * from estudos.modalidades;
select * from estudos.tipos;
select * from estudos.professores;
select * from estudos.usuarios;
select * from estudos.cursos;
select * from estudos.disciplinas;
select * from estudos.historicos;


-- Select da autenticação do usuário
select usuarios.usuNome 
from estudos.usuarios 
where usuarios.usuLogin = 'luci' and usuarios.usuSenha = '123';


-- Select para preenchimento do TableView de Usuarios
select usuarios.usuId Id, 
	   tipos.tipDescricao Tipo,
       usuarios.usuNome Nome, 
       usuarios.usuEmail Email, 
       usuarios.usuTelefone Telefone, 
	   usuarios.usuLogin Login, 
       usuarios.usuSenha Senha 
from usuarios, tipos
where usuarios.usuId = tipos.tipId;
